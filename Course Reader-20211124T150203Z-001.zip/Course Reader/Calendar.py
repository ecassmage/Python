import ScrapeClass


class Calendar:
    def __init__(self, CalendarFile="CalendarFile"):
        self.CalendarFile = CalendarFile
        self.CourseList = {}

        self.file = open(CalendarFile, "a")

        pass

    def saveFile(self):
        file = open(self.CalendarFile, "w")
        for CourseClass in self.CourseList:
            file.write(CourseClass + ": ")
            for Course in self.CourseList[CourseClass]:
                string = ""
                for key in Course:
                    for element in Course[key]:
                        string += element
                file.write(string)
                pass
            file.write("\n")
        file.close()


if __name__ == "__main__":
    calendar = Calendar()
    scrape = ScrapeClass.Scrape("Courses\\COMP2140.html")
    scrape.ReadFile()
    calendar.CourseList = {scrape.Title: scrape.Lectures}
    calendar.saveFile()
